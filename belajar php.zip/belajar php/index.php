<!-- ini aturan penulisan synntax php -->
<?php
echo "Hello, world";
?>

<!-- ini untuk komerntar satu baris -->

<?php
$nama = "Agus";
$umur = 25;
$tinggi = 1.75;

echo "Nama:" . $nama . "<br>";
echo "Umur:" . $umur . "<br>";
echo "Tinggi:" . $tinggi . " meter<br>";
?>

<?php
$is_student = false;
$gaji = 1500000.00;
echo "Status Mahasiswa: " . $is_student . "<br>";
echo "Gaji: " . $gaji;
?>

