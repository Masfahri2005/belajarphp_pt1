<?php
define("PI", 3.14);
$radius = 15;
$luas = PI * $radius * $radius;

echo "Luas Lingkaran dengan radius $radius adalah: " . $luas;
?>