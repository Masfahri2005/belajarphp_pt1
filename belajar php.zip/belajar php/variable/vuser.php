<?php
$nama = "Rina";
$umur = 20;
$pekerjaan = "Mahasiswa";

echo "Halo, nama saya " . $nama . ", saya berusia " . $umur . " tahun"." pekerjaan saya adalah " . $pekerjaan;
?>