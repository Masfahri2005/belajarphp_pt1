<?php
define("NAMA_SITUS", "Belajar PHP");
define("VERSI", 8.2);

echo "Nama Situs: " . NAMA_SITUS . "<br>";
echo "Versi " . VERSI ;
?>