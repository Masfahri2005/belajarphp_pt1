<?php
$numbers = [1, 2, 3, 4, 5];

// menggunakan array_map untuk mengalikan setiap elemen dengan 2 kali
$doubled = array_map(function($num) {
  return $num * 2;
}, $numbers);

print_r($doubled);
?>