<?php
$fruits = ["Apel", "Pisang", "Jeruk", "Mangga"];

// Menampilkan array yang kita punya
foreach($fruits as $fruit) {
  echo $fruit . "<br>";
}

// Akses elemen array berdasarkan index
echo "Buah yang paling kamu sukai adalah: " . $fruits[3];//output yang dihasilkan apel
?>

