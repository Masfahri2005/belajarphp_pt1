<?php

$numbers = [1, 2, 3];

// menambahkan elemen ke dalam array
array_push($numbers, 4, 5);
print_r($numbers);

// hapus elemen terkahir dari array
array_pop($numbers);
print_r($numbers);

// menggabungkan dua array sekaligus
$moreNumbers = [6, 7];
$mergedArray = array_merge($numbers, $moreNumbers);
print_r($mergedArray);
?>

<!-- array push untuk menambahkan elemen terakhir kedalam array -->
 <!-- array pop untuk menghapus elemen terkahir dari array -->
  <!-- array merge untuk menggabungkan dua array menjadi satu array -->