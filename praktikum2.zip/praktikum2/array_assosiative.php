<?php
// buat array assosiative
$ages = [
  "Budi" => 25,
  "Rani" => 20,
  "Anto" => 19
];

foreach($ages as $name => $age){
  echo "$name berusia:  $age tahun<br>";
}

// akses elemen array assosiative
echo "Usia Budi adalah: " . $ages["Budi"] . " Tahun";
?>
