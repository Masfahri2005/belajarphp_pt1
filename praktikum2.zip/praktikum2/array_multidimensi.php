<?php
// buat array multidimensi
$mahasiswas = [
  ['name' => "John", "age" => 25, "grade" => "A"],
  ['name' => "Alice", "age" => 30, "grade" => "B"],
  ['name' => "Bob", "age" => 22, "grade" => "C"],
];

// tampilakan array multidimendi
foreach($mahasiswas as $mahasiswa) {
  echo "Nama: " . $mahasiswa["name"] . ", Usia: " . $mahasiswa["age"] . ", Nilai: " . $mahasiswa["grade"] . "<br>";
}

// akses elemen array multidimensi
echo "Nilai Bob: " . $mahasiswas[2]["grade"]; //output C
?>